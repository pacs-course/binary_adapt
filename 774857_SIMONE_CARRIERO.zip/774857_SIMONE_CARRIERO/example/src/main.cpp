#include "Examples.h"

int main(int argc, char ** argv)
{
	Example1(argc, argv);
	return 0;
};

