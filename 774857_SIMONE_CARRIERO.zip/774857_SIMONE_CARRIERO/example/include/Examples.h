#ifndef __EXAMPLES_H
#define __EXAMPLES_H

void Example1(int argc, char** argv);

#endif //__EXAMPLES_H
