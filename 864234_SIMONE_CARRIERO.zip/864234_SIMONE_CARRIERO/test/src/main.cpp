#include "Test.h"

int main(int argc, char** argv)
{
//	test6	(argc, argv);
//	test7	(argc, argv);
//	test8	(argc, argv);
//	test9	(argc, argv);
//	test10(argc, argv); //perche' il primo polinomio non integrato esattamente ha norma nulla?
//	test11(argc, argv);
//	test12(argc, argv);

//	test13(argc, argv);

//	test14(argc, argv);

//	test15(argc, argv);
//	test16(argc, argv);

	::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}
