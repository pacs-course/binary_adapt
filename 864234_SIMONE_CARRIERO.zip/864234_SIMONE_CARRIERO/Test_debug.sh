#!/bin/sh
clear ;make;
cd ./test;
./bin/test_Debug
cd ..;
