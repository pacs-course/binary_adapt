#!/bin/sh
clear ;make;
cd ./example/example$1;
./bin/example_Debug
cd ../..
