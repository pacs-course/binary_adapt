#!/bin/sh
clear ;make
./Test_check.sh;
