#!/bin/sh
clear ;make;
cd ./test;
gdb ./bin/test_Debug;
cd ..;

